Log subdirectories are automatically created in this directory.
