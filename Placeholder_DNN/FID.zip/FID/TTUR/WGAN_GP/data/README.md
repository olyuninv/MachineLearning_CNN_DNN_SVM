This directory holds the data directories for the training and validation datasets.
