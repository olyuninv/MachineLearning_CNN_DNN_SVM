Contents of the Inception-v3 model.

Get it from here:

http://download.tensorflow.org/models/image/imagenet/inception-2015-12-05.tgz

and unpack it in the projects root directory (WGAN_GP).
