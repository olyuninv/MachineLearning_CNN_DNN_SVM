Tensorboard logfiles, samples, checkpoints will be stored in automatically generated subdirectories here.
