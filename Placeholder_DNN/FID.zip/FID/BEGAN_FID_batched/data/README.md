Data folder, e.g. celebA_cropped or lsun_cropped directories are located here if not specified otherwise.
