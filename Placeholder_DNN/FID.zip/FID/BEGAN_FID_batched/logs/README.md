Tensorboard logfiles, samples, checkpoints will stored in autmatically generated subdirectories here.
