BEGAN fork from

https://github.com/carpedm20/BEGAN-tensorflow

with batched FID evaluation

Needs fid.py from TTUR root directory. Please copy it here. 

Precalculated real world / training data statistics can be downloaded
from here. Be sure to use the batched versions.

http://bioinf.jku.at/research/ttur/ttur.html

see sh/run.sh for options

Fixed random seeds are removed.
