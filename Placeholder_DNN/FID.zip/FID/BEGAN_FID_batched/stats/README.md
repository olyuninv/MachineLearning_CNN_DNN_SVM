Folder for precalculated FID statistics
